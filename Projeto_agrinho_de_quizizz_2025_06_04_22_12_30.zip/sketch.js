let perguntas = [
  {
    pergunta: "Qual a capital do Brasil?",
    opcoes: ["São Paulo", "Brasília", "Rio de Janeiro", "Salvador"],
    resposta: 1 // Índice da resposta correta (Brasília)
  },
  {
    pergunta: "Quem pintou a Mona Lisa?",
    opcoes: ["Van Gogh", "Picasso", "Da Vinci", "Monet"],
    resposta: 2 // Índice da resposta correta (Da Vinci)
  },
  {
    pergunta: "Qual é o maior planeta do Sistema Solar?",
    opcoes: ["Terra", "Júpiter", "Saturno", "Marte"],
    resposta: 1 // Índice da resposta correta (Júpiter)
  }
];

let perguntaAtual = 0;
let respostaSelecionada = -1;
let resultado = "";
let tempoResposta = 0;

function setup() {
  createCanvas(600, 400);
  noStroke();
  textSize(24);
}

function draw() {
  background(240);

  // Desenha a pergunta
  fill(0);
  text(perguntas[perguntaAtual].pergunta, 20, 50);

  // Desenha as opções de resposta
  for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
    let y = 100 + i * 60;
    if (respostaSelecionada === i) {
      fill(200, 255, 200); // Cor de seleção (verde claro)
    } else {
      fill(255);
    }
    rect(20, y, width - 40, 50);
    fill(0);
    text(perguntas[perguntaAtual].opcoes[i], 30, y + 35);
  }

  // Exibe o resultado após a resposta
  if (respostaSelecionada >= 0) {
    if (respostaSelecionada === perguntas[perguntaAtual].resposta) {
      resultado = "Você acertou!";
      fill(0, 255, 0); // Verde para acerto
    } else {
      resultado = "Você errou!";
      fill(255, 0, 0); // Vermelho para erro
    }
    textSize(30);
    text(resultado, width / 2 - textWidth(resultado) / 2, height - 100);
    
    // Espera antes de avançar para a próxima pergunta
    tempoResposta++;
    if (tempoResposta > 120) { // Espera por 2 segundos
      tempoResposta = 0;
      perguntaAtual = (perguntaAtual + 1) % perguntas.length;
      respostaSelecionada = -1;
    }
  }
}

function mousePressed() {
  // Verifica se o jogador clicou em uma opção
  for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
    let y = 100 + i * 60;
    if (mouseX > 20 && mouseX < width - 20 && mouseY > y && mouseY < y + 50) {
      respostaSelecionada = i;
    }
  }
}